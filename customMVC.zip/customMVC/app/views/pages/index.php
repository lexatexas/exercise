<?php require_once APPROOT.'/views/inc/header.php'; ?>

<?php

echo '<h1>'.$data['title']. '</h1></br>';
echo $data['desc'];


?>

<?php require_once APPROOT.'/views/inc/footer.php'; ?>